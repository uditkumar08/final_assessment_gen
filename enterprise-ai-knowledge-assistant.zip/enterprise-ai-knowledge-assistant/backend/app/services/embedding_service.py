
from sentence_transformers import SentenceTransformer

# Load the model
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

model = SentenceTransformer(MODEL_NAME)


def generate_embedding(text: str):

    embedding = model.encode(
        text,
        normalize_embeddings=True
    )

    return embedding


def generate_embeddings(texts: list[str]):

    # Convert multiple text chunks into vectors
    embeddings = model.encode(
        texts,
        normalize_embeddings=True
    )

    return embeddings
