# Enterprise AI Knowledge Assistant

Ask questions about a PDF and get answers grounded in that document, with page references to help you check the source.

This guide is written for someone setting up the project for the first time on Windows. You do not need to know how AI works to try it.

## What does this project do?

Reading a long document to find one detail can take time. This app lets you upload a PDF and ask questions in plain language, such as:

> What does the document say about the cancellation policy?

The app uses **Retrieval-Augmented Generation (RAG)**. In everyday terms, it first searches your document for passages related to your question, then gives those passages to an AI model to write an answer. This helps keep the answer tied to the document instead of relying only on the model's general knowledge.

The main steps are:

1. **Upload:** The backend checks the PDF and extracts its text and page numbers.
2. **Prepare:** The text is split into smaller passages (called *chunks*).
3. **Index:** An embedding model turns each passage into a vector, a numerical representation used to find similar meaning. The vectors and passage text are saved in Qdrant.
4. **Ask:** Your question is converted to a vector. Qdrant finds up to five relevant passages from the selected document.
5. **Answer:** Groq's language model writes an answer using those passages. The response includes source page numbers when available.

If relevant text cannot be found, the assistant is instructed to say so rather than make up an answer. Still, always check important information against the cited PDF.

## What you need

- Windows 10 or 11
- Python 3.12
- Docker Desktop (to run Qdrant, the vector database)
- A Groq API key and a Groq model name
- An internet connection for installing Python packages, downloading the embedding model the first time, and calling Groq

## Run it locally on Windows

Use **three terminal windows**: one for Qdrant, one for the API, and one for the web app.

### 1. Open the project folder

From the repository folder, open PowerShell and enter:

```powershell
cd .\enterprise-ai-knowledge-assistant
```

Run the remaining setup commands from this folder (the one containing `requirements.txt`).

### 2. Start Qdrant

Make sure Docker Desktop is running, then start Qdrant in the first terminal:

```powershell
docker run -d --name enterprise-qdrant -p 6335:6333 -v enterprise_qdrant_data:/qdrant/storage qdrant/qdrant
```

The database keeps its data in a Docker volume, so stopping the container does not remove its stored vectors. If you already created this container, start it with `docker start enterprise-qdrant`.

### 3. Create a Python environment and install packages

In the second terminal, from the project folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell says script execution is disabled when activating the environment, you can activate it for this terminal with:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### 4. Set your Groq credentials

If you do not already have a `.env` file, create one from the example:

```powershell
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
```

Open `.env` in an editor and replace the placeholder values for `GROQ_API_KEY` and `GROQ_MODEL` with your Groq API key and the model name you want to use. The API key is a password: keep it private and do not commit `.env` to version control.

The chat service requires both `GROQ_API_KEY` and `GROQ_MODEL`. The embedding model is `sentence-transformers/all-MiniLM-L6-v2` and is downloaded by the application when needed.

### 5. Start the backend API

In the second terminal, with `.venv` active:

```powershell
python -m uvicorn backend.app.main:app --reload --port 8000
```

Keep this terminal open. The API documentation is available at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs). The first startup may take longer while the embedding model is downloaded.

### 6. Start the web app

Open a third terminal, go to the project folder, and activate the environment:

```powershell
cd .\enterprise-ai-knowledge-assistant
.\.venv\Scripts\Activate.ps1
streamlit run frontend/ui_app.py
```

If the third terminal is already in the project folder, skip the `cd` command. Streamlit prints a local URL; open it in your browser (usually [http://localhost:8501](http://localhost:8501)).

### 7. Upload and ask

1. Choose a PDF in the web app and select **Upload and Start Chat**.
2. Wait until processing finishes.
3. Ask a question about the uploaded document.
4. Expand **View Sources** under an answer to see the page numbers used.

The current upload endpoint accepts one PDF at a time, up to 10 MB. The PDF needs to contain selectable text; scanned image-only PDFs are not processed with OCR.

## Using the API directly

The web app is the simplest way to try the project. You can also use the interactive API page at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs):

- `POST /documents/upload-and-index` uploads, extracts, and indexes a PDF. Its response contains a `document_id`.
- `POST /chat/query` answers a question for that document. Send a JSON body like:

```json
{
  "document_id": "the-id-returned-by-upload",
  "question": "What does the document say about the cancellation policy?"
}
```

The chat response includes the question, document ID, answer, and a `sources` list with page numbers and retrieval scores. A score indicates how closely a passage matched the question; it is not a guarantee that the answer is correct. Questions must be between 1 and 2,000 characters.

## Project map

| Path | What it is for |
| --- | --- |
| `backend/app/main.py` | Creates the FastAPI application and registers API routes. |
| `backend/app/api/documents.py` | Validates PDF uploads and runs the upload-and-index workflow. |
| `backend/app/api/chat.py` | Defines the chat endpoint and validates questions. |
| `backend/app/services/pdf_service.py` | Extracts text and page numbers from PDFs. |
| `backend/app/services/document_chunking.py` | Splits extracted document text into passages. |
| `backend/app/services/embedding_service.py` | Converts passages and questions into vectors. |
| `backend/app/services/qdrant_service.py` | Stores and searches document passages in Qdrant. |
| `backend/app/services/indexing_service.py` | Connects chunking, embeddings, and Qdrant storage. |
| `backend/app/services/rag_service.py` | Retrieves passages and builds the document-grounded answer. |
| `frontend/ui_app.py` | Provides the Streamlit upload and chat interface. |
| `storage/uploads/` | Holds uploaded PDF files. |
| `storage/processed/` | Holds extracted document text and intermediate chunk data. |

## Troubleshooting

- **The chat page cannot connect to the backend:** Start the API and make sure it is listening on port `8000`.
- **Qdrant connection errors:** Make sure Docker Desktop is running and the Qdrant container is listening on port `6335`. The current backend code uses `http://localhost:6335`.
- **Missing Groq settings:** Check that `.env` is in the project folder and contains non-placeholder values for `GROQ_API_KEY` and `GROQ_MODEL`. Restart the backend after editing it.
- **No readable PDF text:** The current PDF extraction supports text-based PDFs, not OCR for scanned pages.
- **An answer says it could not find information:** Try asking with terms used in the document, or confirm that the uploaded PDF contains the answer.
- **PowerShell cannot find `py`:** Install Python 3.12 and enable the Python launcher during setup.

## Configuration note

The local instructions above match the current code: the backend connects to Qdrant at `http://localhost:6335`, and the Streamlit app connects to the API at `http://127.0.0.1:8000`. The existing Docker Compose configuration uses different container networking and ports, so it is not covered as a working launch option here. In particular, changing `QDRANT_URL` in `.env` alone does not change the backend's current hard-coded Qdrant URL.
